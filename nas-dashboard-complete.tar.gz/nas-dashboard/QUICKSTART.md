# البدء السريع - NAS Dashboard

## 🚀 ابدأ في 5 دقائق!

---

## الخطوة 1️⃣: فك الضغط
```bash
tar -xzf nas-dashboard.tar.gz
cd nas-dashboard
```

## الخطوة 2️⃣: التثبيت
```bash
chmod +x install.sh
sudo ./install.sh
```

## الخطوة 3️⃣: الوصول
```
افتح المتصفح واذهب إلى:
http://YOUR-SERVER-IP/nas-dashboard
```

## الخطوة 4️⃣: تسجيل الدخول
```
اسم المستخدم: admin
كلمة المرور: admin
```

## الخطوة 5️⃣: غير كلمة المرور!
```
الإعدادات > المستخدمون > تعديل > غيّر كلمة المرور
```

---

## ✅ انتهى! استمتع!

للمزيد من التفاصيل:
- README.md - نظرة عامة
- INSTALLATION_GUIDE.md - دليل التثبيت المفصل
- USER_GUIDE.md - دليل الاستخدام

---

## 📋 قائمة التحقق السريعة

- [ ] فك ضغط الملف
- [ ] تشغيل install.sh
- [ ] فتح المتصفح
- [ ] تسجيل الدخول
- [ ] تغيير كلمة المرور
- [ ] إنشاء مستخدمين جدد
- [ ] إعداد المجلدات المشتركة
- [ ] إنشاء أول جهاز وهمي

---

## 🆘 مشاكل؟

### لا يعمل التثبيت؟
```bash
# تحقق من السجلات
sudo tail -f /var/log/apache2/error.log
```

### لا يمكن الوصول؟
```bash
# تحقق من Apache
sudo systemctl status apache2
```

### خطأ في قاعدة البيانات؟
```bash
# تحقق من MariaDB
sudo systemctl status mariadb
```

---

**تحتاج مساعدة؟ راجع INSTALLATION_GUIDE.md للتفاصيل الكاملة!**
