# NAS Dashboard - لوحة تحكم NAS عصرية

لوحة تحكم شاملة وعصرية لإدارة خادم NAS الخاص بك مع واجهة عربية جميلة.

## المميزات ✨

### 🎛️ لوحة التحكم الرئيسية (Dashboard)
- عرض إحصائيات النظام في الوقت الفعلي
- مراقبة استخدام المساحة التخزينية
- عرض حالة الأجهزة الوهمية النشطة
- إحصائيات المستخدمين النشطين
- حالة الشبكة والاتصال

### 📱 التطبيقات (Applications)
- إدارة الملفات (File Manager)
- خادم الوسائط (Media Server)
- مدير التحميلات (Download Manager)
- إدارة النسخ الاحتياطي (Backup Manager)
- مراقبة الشبكة (Network Monitor)

### 🖥️ الأجهزة الوهمية (Virtual Machines)
- إنشاء أجهزة وهمية باستخدام Docker
- دعم أنظمة Linux:
  - Ubuntu (24.04, 22.04, 20.04)
  - Debian (latest, bookworm, bullseye)
  - Fedora (latest, 39)
  - Arch Linux
  - Manjaro
  - CentOS
  - Alpine
  - Kali Linux
  - openSUSE
- دعم أنظمة Windows:
  - Windows Server 2022
  - Windows Server 2019
  - Windows Server Core
  - Windows Nano Server
- تحكم كامل في الموارد (CPU, RAM, Disk)
- تخصيص IP حقيقي من الراوتر
- إدارة سهلة (تشغيل/إيقاف/حذف)

### 📁 المجلدات المشتركة (Shared Folders)
- إنشاء مجلدات مشتركة على الشبكة
- دعم المجلدات العامة والخاصة
- صلاحيات متقدمة للمستخدمين (قراءة/كتابة/حذف)
- حماية بكلمة مرور
- تحديد الحجم الأقصى

### 📹 كاميرات المراقبة (IP Cameras)
- إضافة كاميرات IP
- دعم بروتوكولات RTSP, HTTP, ONVIF
- عرض مباشر للكاميرات
- تسجيل الفيديو
- مراقبة حالة الاتصال

### ⚙️ الإعدادات (Settings)
- **إعدادات النظام:**
  - اسم السيرفر
  - المنطقة الزمنية
  - اللغة
  
- **إعدادات الشبكة:**
  - SSH (Port 22)
  - FTP (Port 21)
  - SFTP (Port 22)
  - HTTP (Port 80)
  - HTTPS (Port 443)
  - SMB (Port 445)
  - NFS (Port 2049)
  - RTSP (Port 554)
  - WebDAV (Port 8080)
  - MySQL (Port 3306)
  - Redis (Port 6379)
  - Docker API (Port 2375)
  
- **إدارة المستخدمين:**
  - إضافة مستخدمين جدد
  - تحديد الصلاحيات
  - أدوار مختلفة (Admin, User, Guest)

## متطلبات التشغيل 📋

### الحد الأدنى:
- نظام Linux (Ubuntu 20.04+, Debian 11+, CentOS 8+, Fedora 35+)
- معالج: 2 Core CPU
- ذاكرة: 2 GB RAM
- مساحة: 20 GB HDD/SSD
- اتصال بالإنترنت

### الموصى به:
- معالج: 4+ Core CPU
- ذاكرة: 8+ GB RAM
- مساحة: 500+ GB HDD/SSD
- شبكة: Gigabit Ethernet

## التثبيت 🚀

### 1. تحميل المشروع
```bash
# تحميل المشروع
git clone https://github.com/your-repo/nas-dashboard.git
cd nas-dashboard
```

### 2. تشغيل سكريبت التثبيت
```bash
# منح صلاحيات التنفيذ
chmod +x install.sh

# تشغيل التثبيت (يحتاج صلاحيات root)
sudo ./install.sh
```

### 3. الوصول إلى لوحة التحكم
بعد اكتمال التثبيت، يمكنك الوصول إلى لوحة التحكم من خلال:
```
http://YOUR-SERVER-IP/nas-dashboard
```

### بيانات الدخول الافتراضية:
- **اسم المستخدم:** admin
- **كلمة المرور:** admin

⚠️ **مهم:** يرجى تغيير كلمة المرور فوراً بعد تسجيل الدخول الأول!

## التثبيت اليدوي 🔧

إذا كنت تفضل التثبيت اليدوي:

### 1. تثبيت المتطلبات
```bash
# Ubuntu/Debian
sudo apt-get update
sudo apt-get install apache2 php php-mysql mariadb-server docker.io samba vsftpd

# CentOS/RHEL/Fedora
sudo yum install httpd php php-mysqlnd mariadb-server docker samba vsftpd
```

### 2. إعداد قاعدة البيانات
```bash
# تشغيل MySQL/MariaDB
sudo systemctl start mariadb
sudo systemctl enable mariadb

# إنشاء قاعدة البيانات
sudo mysql -u root < database.sql
```

### 3. نسخ الملفات
```bash
# نسخ إلى مجلد الويب
sudo cp -r * /var/www/html/nas-dashboard/

# تعيين الصلاحيات
sudo chown -R www-data:www-data /var/www/html/nas-dashboard
sudo chmod -R 755 /var/www/html/nas-dashboard
```

### 4. تشغيل الخدمات
```bash
sudo systemctl start apache2
sudo systemctl start docker
sudo systemctl start smbd
sudo systemctl start vsftpd
```

## البنية التحتية 🏗️

```
nas-dashboard/
├── api/                    # ملفات API الخلفية
│   ├── login.php          # تسجيل الدخول
│   ├── logout.php         # تسجيل الخروج
│   ├── check_auth.php     # التحقق من الجلسة
│   ├── stats.php          # إحصائيات النظام
│   ├── applications.php   # إدارة التطبيقات
│   ├── vm.php             # إدارة الأجهزة الوهمية
│   ├── folders.php        # إدارة المجلدات
│   ├── cameras.php        # إدارة الكاميرات
│   ├── settings.php       # الإعدادات
│   ├── user.php           # معلومات المستخدم
│   └── status.php         # حالة السيرفر
├── config/                 # ملفات الإعدادات
│   └── database.php       # اتصال قاعدة البيانات
├── js/                     # ملفات JavaScript
│   └── main.js            # الملف الرئيسي
├── login.html             # صفحة تسجيل الدخول
├── dashboard.html         # لوحة التحكم الرئيسية
├── database.sql           # قاعدة البيانات
├── install.sh             # سكريبت التثبيت
└── README.md              # هذا الملف
```

## الميزات التقنية 💻

### Frontend
- **HTML5 & CSS3** مع تصميم عصري وجميل
- **JavaScript (Vanilla)** بدون مكتبات خارجية
- **Responsive Design** متجاوب مع جميع الأجهزة
- **Font Awesome Icons** للأيقونات
- **تأثيرات وانتقالات سلسة**

### Backend
- **PHP 7.4+** 
- **MySQL/MariaDB** لقاعدة البيانات
- **RESTful API** للاتصال
- **Session Management** لإدارة الجلسات
- **PDO** للتعامل الآمن مع قاعدة البيانات

### التكنولوجيات المستخدمة
- **Docker** للأجهزة الوهمية
- **Samba** لمشاركة الملفات
- **FTP/SFTP** لنقل الملفات
- **SSH** للوصول الآمن

## الأمان 🔒

- تشفير كلمات المرور باستخدام bcrypt
- حماية من SQL Injection
- جلسات آمنة
- تسجيل النشاطات
- صلاحيات متعددة المستويات

## الدعم والمساعدة 📞

إذا واجهت أي مشاكل:
1. تحقق من ملف logs في `/var/log/apache2/`
2. تأكد من تشغيل جميع الخدمات المطلوبة
3. تحقق من صلاحيات الملفات

## الترخيص 📄

هذا المشروع مفتوح المصدر ومتاح للجميع.

## المساهمة 🤝

نرحب بجميع المساهمات! يمكنك:
- الإبلاغ عن المشاكل (Issues)
- اقتراح ميزات جديدة
- إرسال Pull Requests

---

تم التطوير بواسطة ❤️ لمجتمع NAS

**إصدار:** 1.0.0
**آخر تحديث:** 2026
